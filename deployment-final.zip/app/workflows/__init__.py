"""
LangGraph Workflow Integration for Credit Risk Analysis
====================================================

This module provides LangGraph-based workflow visualization and orchestration
for the multi-agent credit risk analysis system.
"""

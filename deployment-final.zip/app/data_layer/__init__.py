"""Data layer for Databricks integration"""

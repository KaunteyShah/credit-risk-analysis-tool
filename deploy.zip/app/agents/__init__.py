"""Multi-agent system for credit risk analysis"""

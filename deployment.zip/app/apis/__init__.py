"""External API integrations"""

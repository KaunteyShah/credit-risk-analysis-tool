"""Application utilities"""

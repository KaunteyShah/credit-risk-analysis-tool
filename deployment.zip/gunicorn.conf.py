# Gunicorn configuration for Azure App Service
import os

# Azure App Service provides port via WEBSITES_PORT
port = os.environ.get('WEBSITES_PORT') or os.environ.get('PORT', '8000')
bind = f"0.0.0.0:{port}"

workers = 1
worker_class = "sync"
worker_connections = 1000
timeout = 120
keepalive = 2
max_requests = 1000
max_requests_jitter = 100
preload_app = True

# Logging
loglevel = "info"
accesslog = "-"
errorlog = "-"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process naming
proc_name = "credit-risk-flask-app"

# Server socket
backlog = 2048
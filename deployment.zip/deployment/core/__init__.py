"""Core application components"""
